<?php
     $username = 'root'; // to check username and pass go to config.inc.php file into C:\xampp\phpMyAdmin
     $password = '';
     $server = 'localhost';
     $db = 'project_db'; // database name that we created in phpmyadmin 
?> 